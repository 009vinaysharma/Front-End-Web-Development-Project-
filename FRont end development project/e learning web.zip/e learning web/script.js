// Wait for splash screen animation to finish before showing main content
window.onload = function() {
  // Initially hide everything until user clicks to proceed
  document.getElementById("main-header").classList.add("hidden");
  document.getElementById("content").classList.add("hidden");
};

// Proceed when the user clicks "Click to Continue" button
function proceed() {
  document.getElementById("splash-screen").style.display = "none";  // Hide splash screen
  document.getElementById("main-header").classList.remove("hidden");  // Show header
  document.getElementById("content").classList.remove("hidden");  // Show content
}

// Function to toggle the visibility of the Home content when the Home button is clicked
function toggleHomeContent() {
    var homeContent = document.getElementById("home-content");
    
    // Toggle the display property between block and none
    if (homeContent.style.display === "none") {
        homeContent.style.display = "block";
    } else {
        homeContent.style.display = "none";
    }
}

// Example functions for the other navigation links
function showCourses() {
    alert("Show Courses Section");
}

function showLogin() {
    alert("Show Login Section");
}

function showAbout() {
    alert("Show About Us Section");
}

function showContact() {
    alert("Show Contact Section");
}


function showCourseDetail(courseName) {
    let content = document.getElementById("content");
    content.innerHTML = `
      <div class="course-card enlarged">
        <h3>${courseName}</h3>
        <p>This is the detailed information for ${courseName}.</p>
        <h4>Recommended Books and Study Materials</h4>
        <ul>
          <li><a href="https://www.example.com/book1" target="_blank">Book 1: Introduction to ${courseName}</a></li>
          <li><a href="https://www.example.com/book2" target="_blank">Book 2: Advanced ${courseName}</a></li>
          <li><a href="https://www.example.com/resource1" target="_blank">Free Resource 1</a></li>
          <li><a href="https://www.example.com/resource2" target="_blank">Free Resource 2</a></li>
        </ul>
        <button onclick="backToCourses()">Back to Courses</button>
      </div>
    `;
  }

  

// Show content for Courses
function showCourses() {
  document.getElementById("content").innerHTML = `
    <h2>Available Courses</h2>
    <div class="course-card" onclick="showCourseDetail('Web Development')">
      <h3>Web Development</h3>
      <p>Learn the fundamentals of web development.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Data Science')">
      <h3>Data Science</h3>
      <p>Get started with data science and machine learning.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Digital Marketing')">
      <h3>Digital Marketing</h3>
      <p>Master the skills of digital marketing.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Graphic Design')">
      <h3>Graphic Design</h3>
      <p>Learn the art of visual design.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Python Programming')">
      <h3>Python Programming</h3>
      <p>Master the basics of Python programming.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('JavaScript')">
      <h3>JavaScript</h3>
      <p>Understand the core concepts of JavaScript.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Mobile App Development')">
      <h3>Mobile App Development</h3>
      <p>Create apps for Android and iOS.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Machine Learning')">
      <h3>Machine Learning</h3>
      <p>Dive into machine learning and AI.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Cybersecurity')">
      <h3>Cybersecurity</h3>
      <p>Learn to protect systems from cyber threats.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('Blockchain')">
      <h3>Blockchain</h3>
      <p>Understand the concepts of blockchain technology.</p>
    </div>
    <div class="course-card" onclick="showCourseDetail('UI/UX Design')">
      <h3>UI/UX Design</h3>
      <p>Learn how to design user interfaces and experiences.</p>
    </div>
  `;
}

// Show detailed view of a course (Enlarge content)
function showCourseDetail(courseName) {
  let content = document.getElementById("content");
  content.innerHTML = `
    <div class="course-card enlarged">
      <h3>${courseName}</h3>
      <p>This is the detailed information for ${courseName}.</p>
      <button onclick="backToCourses()">Back to Courses</button>
    </div>
  `;
}

// Show login form
function showLogin() {
  document.getElementById("content").innerHTML = `
    <div class="center-content">
      <div class="login-form">
        <h2>Login</h2>
        <form>
          <input type="text" id="name" placeholder="Name" required><br><br>
          <input type="email" id="email" placeholder="Gmail" required><br><br>
          <input type="password" id="password" placeholder="Password" required><br><br>
          <button type="submit">Login</button>
        </form>
        <div class="register-link">
          <p>Click <a href="javascript:void(0);" onclick="showRegister()">here</a> for Registration</p>
        </div>
      </div>
    </div>
  `;
}

// Show register form (for future use)
function showRegister() {
  document.getElementById("content").innerHTML = `
    <div class="center-content">
      <div class="login-form">
        <h2>Register Now</h2>
        <form>
          <label for="username">Username:</label>
          <input type="text" id="username" required><br><br>
          <label for="email">Email:</label>
          <input type="email" id="email" required><br><br>
          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  `;
}

// Show about us section
function showAbout() {
    document.getElementById("content").innerHTML = `
      <div class="center-text" style="background-color: #f4f4f4; color: #333; padding: 10px; border-radius: 10px;">
        <p>We offer a variety of courses to help you learn new skills and advance your career. Join us today!</p>
      </div>
    `;
  }
  

// Show contact information
function showContact() {
  document.getElementById("content").innerHTML = `
    <div class="center-text">
      <p>Contact us at <a href="mailto:sharmavinay009874@gmail.com">sharmavinay00974@gmail.com</a></p>
    </div>
  `;
}
